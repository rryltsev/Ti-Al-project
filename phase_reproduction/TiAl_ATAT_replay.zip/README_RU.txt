Ti–Al • ATAT 3.52 • CPU MTP Qi et al.

design/lat.in — родительская ГПУ-решётка для ATAT.
design/clusters.out — 20 орбит в собственном порядке ATAT.
design/design.csv — 39 обучающих и 7 контрольных ячеек, признаки нормированы на атом.
design/selected/<id>/str.out — химическая ячейка в координатах ATAT.
design/selected/<id>/corr.out — сырые корреляции ATAT выбранной ячейки.
design/cells/<id>.cfg — та же декорация при физическом опорном объёме для MTP.
design/jobs.csv — сетки объёмов, суперячеек и q-точек.
design/native/S1_round_eV_atom.eci — только ориентир из печатной таблицы S1.

Результаты собственной подгонки и экспорта помещены в fit/.

Воспроизведение подгонки при опорном объёме из каталога распакованного архива (Python 3.10+, NumPy):
python code/atomistic/fit_eci.py design labels/v100.tar.gz fitted_vref --ratios 1
python code/atomistic/atat/export_eci.py design fitted_vref/grid.npz native_HA1000 --temperature 1000
Для проверки нативным ATAT добавьте к последней команде --corrdump /absolute/path/to/corrdump.
Таблица tables/MTP_labels_414.csv включает прямую статику, фононный флаг устойчивости и 49 значений Fvib для устойчивых состояний.
Таблица tables/ECI_TV.csv содержит Jstatic, Jvib и их сумму для 20 орбит на девяти объёмах при 49 температурах.
В native_lsfit/eci_thermal_grid.csv собраны коэффициенты из нативной программы ATAT lsfit. Там же сохранены матрицы и проверка corrdump с UMT.

Qi et al. MTP: see potential/source.json for the DOI, archive member and SHA-256. The saved labels are sufficient for both replay commands.
